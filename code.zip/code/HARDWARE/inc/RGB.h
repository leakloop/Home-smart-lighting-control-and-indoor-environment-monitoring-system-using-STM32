#ifndef _LED_H
#define _LED_H

//#ifdef __cplusplus
 //extern "C" {
//#endif

#define RED     1
#define GREEN   2
#define BLUE    3
#define YELLOW  4
#define PURPLE  5
#define NAVY    6
#define WHITE   7

typedef enum { false= 0, true = !false} bool;	 
	 
void rgb_init(void);
void rgb_ctrl(u8 colour, bool state);
	 
//#ifdef __cplusplus
//}
//#endif
#endif
