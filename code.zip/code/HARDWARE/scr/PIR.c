#include "stm32f10x.h"                  // Device header
#include "PIR.h"

void PIR_Init(void)
{
		GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	

	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
}
 uint8_t PIROUT(void)
 {
	 uint8_t flag=0;
	  if (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9) == 1)
	{
		 flag=1;
	}
	else
	{
	 flag=0;
	}
	return flag;
}
