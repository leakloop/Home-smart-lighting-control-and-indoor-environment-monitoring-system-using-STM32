#include "stm32f10x.h"                  // Device header
#include "RGB.h"
void rgb_init(void)
{
		GPIO_InitTypeDef GPIO_InitStructure;
		RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	
		GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_10;    
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;       
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOB, &GPIO_InitStructure);

      GPIO_ResetBits(GPIOB, GPIO_Pin_0);
      GPIO_ResetBits(GPIOB, GPIO_Pin_1);
      GPIO_ResetBits(GPIOB, GPIO_Pin_10);//��ʼ���õ͵�ƽ
//		GPIO_SetBits(GPIOB, GPIO_Pin_0);
//		GPIO_SetBits(GPIOB, GPIO_Pin_1);
//		GPIO_SetBits(GPIOB, GPIO_Pin_10);
}

void rgb_ctrl(u8 colour, bool state)   //��ԭɫ���
{
    switch(colour){
        case RED:
            if(state){
              GPIO_SetBits(GPIOB, GPIO_Pin_0);  		             
            }
            else {         
							GPIO_ResetBits(GPIOB, GPIO_Pin_0);	
            }
            break;
        case GREEN:
            if(state){
                   GPIO_SetBits(GPIOB, GPIO_Pin_1);
            }
            else{		    
							 GPIO_ResetBits(GPIOB, GPIO_Pin_1);
            }
            break;
        case BLUE:
            if(state){
              GPIO_SetBits(GPIOB, GPIO_Pin_10);
            }
            else {       
							 GPIO_ResetBits(GPIOB, GPIO_Pin_10);
            }
            break;
        case YELLOW:
            if(state){
               GPIO_SetBits(GPIOB, GPIO_Pin_0);
                GPIO_SetBits(GPIOB, GPIO_Pin_1);
            }
            else{
               
							  GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                GPIO_ResetBits(GPIOB, GPIO_Pin_1);
            }
            break;
        case PURPLE:
            if(state){
             GPIO_SetBits(GPIOB, GPIO_Pin_0);
                GPIO_SetBits(GPIOB, GPIO_Pin_10);
                }
            else{
							 GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                GPIO_ResetBits(GPIOB, GPIO_Pin_10);
            }
            break;
        case NAVY:
            if(state){
                GPIO_SetBits(GPIOB, GPIO_Pin_1);
                GPIO_SetBits(GPIOB, GPIO_Pin_10);
            }
            else{
							 GPIO_ResetBits(GPIOB, GPIO_Pin_1);
                GPIO_ResetBits(GPIOB, GPIO_Pin_10);
            }
            break;
        case WHITE:
            if(state){
                 GPIO_SetBits(GPIOB, GPIO_Pin_0);
                GPIO_SetBits(GPIOB, GPIO_Pin_1);
                GPIO_SetBits(GPIOB, GPIO_Pin_10);
            }
            else{
							GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                GPIO_ResetBits(GPIOB, GPIO_Pin_1);
                GPIO_ResetBits(GPIOB, GPIO_Pin_10);
            }
            break;
        default:
            break;
    }
}

